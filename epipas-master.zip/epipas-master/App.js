/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {View} from 'react-native';
import App from './src/index';
import FavoritosScreen from './src/screens/Favoritos';


export default function Main(){
  return(
    <App />
  );

}
  